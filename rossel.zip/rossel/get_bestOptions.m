function [options] = get_bestOptions(options,resultDir,dataName,method,nlabel,nUnlabel,idx_run,nK)
% read the bestOptions


switch method
    case 'lapsvm_s'
        switch dataName
            case 'CNAE-9'
                saveFile = sprintf('%s/%s_%s_nl%d_nun%d_run%d.mat',...
                    resultDir,dataName,method,nlabel,nUnlabel,idx_run);
            otherwise
                saveFile = sprintf('%sbest/%s_%s_nl%d_nun%d_run%d.mat',...
                    resultDir,dataName,method,nlabel,nUnlabel,idx_run);
        end
        load(saveFile,'bestOptions_lapsvm')
        
        options = bestOptions_lapsvm;
        
    case 'laprls_s'
        switch dataName
            case 'CNAE-9'
                saveFile = sprintf('%s/%s_%s_nl%d_nun%d_run%d.mat',...
                    resultDir,dataName,method,nlabel,nUnlabel,idx_run);
            otherwise
                saveFile = sprintf('%sbest/%s_%s_nl%d_nun%d_run%d.mat',...
                    resultDir,dataName,method,nlabel,nUnlabel,idx_run);
        end
        load(saveFile,'bestOptions_laprls')
        
        options = bestOptions_laprls;
        
    case 'asl'
        saveFile = sprintf('%s%s_%s_nl%d_nun%d_run%d.mat',...
            resultDir,dataName,method,nlabel,nUnlabel,idx_run);
        load(saveFile,'bestOptions_asl')
        
        tmp_str1 = regexp(bestOptions_asl,'r1','split');
        tmp_str2 = regexp(tmp_str1{2},'_','split');
        options.r1 = str2num(tmp_str2{1});
        
        tmp_str1 = regexp(bestOptions_asl,'inMaxIter','split');
        options.inMaxIter = str2num(tmp_str1{2});
        
        if options.r1==0
            options.r1 = 1e-5;
        end
        if options.inMaxIter==0
            options.inMaxIter = 1e-5;
        end
                
    case 'cs4vm'
        saveFile = sprintf('%s%s_%s_nl%d_nun%d_run%d.mat',...
            resultDir,dataName,method,nlabel,nUnlabel,idx_run);
        load(saveFile,'bestOptions_cs4vm')
        
        switch dataName
            case 'connect-4-10k'
                tmp_str1 = regexp(bestOptions_cs4vm,'c1','split');
                tmp_str2 = regexp(tmp_str1{2},'_','split');
                options.c1 = str2num(tmp_str2{1});

                tmp_str1 = regexp(bestOptions_cs4vm,'c2','split');
                options.c2 = str2num(tmp_str1{2});
                
            otherwise
                tmp_str1 = regexp(bestOptions_cs4vm,'c1','split');
                tmp_str2 = regexp(tmp_str1{2},'_','split');
                options.c1 = str2num(tmp_str2{1});

                tmp_str1 = regexp(bestOptions_cs4vm,'c2','split');
                options.c2 = str2num(tmp_str1{2});
                
        end
        
        if options.c1==0
            options.c1 = 1e-5;
        end
        if options.c2==0
            options.c2 = 1e-5;
        end
        
        
    case 'means3vm'
        saveFile = sprintf('%s%s_%s_nl%d_nun%d_run%d.mat',...
            resultDir,dataName,method,nlabel,nUnlabel,idx_run);
        load(saveFile,'bestOptions_means3vm')
        
        tmp_str1 = regexp(bestOptions_means3vm,'c1','split');
        tmp_str2 = regexp(tmp_str1{2},'_','split');
        options.c1 = str2num(tmp_str2{1});
        
        tmp_str1 = regexp(bestOptions_means3vm,'c2','split');
        options.c2 = str2num(tmp_str1{2});
        
        if options.c1==0
            options.c1 = 1e-5;
        end
        if options.c2==0
            options.c2 = 1e-5;
        end
        
    case 'enmctran_par'
        if strcmp(dataName,'protein.all')
            saveFile = sprintf('%s%s_%s_nl%d_nUlbl%d_nL%d_run%d.mat',...
            resultDir,dataName,method,nlabel,nUnlabel,...
            nK*2,idx_run);
        else
            saveFile = sprintf('%s%s_%s_nl%d_nUlbl%d_nL%d_run%d.mat',...
                resultDir,dataName,method,nlabel,nUnlabel,...
                nK,idx_run);
        end
        load(saveFile,'bestParam')
        
        tmp_str1 = regexp(bestParam,'C1','split');
        tmp_str2 = regexp(tmp_str1{2},'_','split');
        options.tranC1 = str2num(tmp_str2{1});

        tmp_str1 = regexp(bestParam,'C2','split');
        options.tranC2 = str2num(tmp_str1{2});
        
        if options.tranC1==0
            options.tranC1 = 1e-5;
        end
        if options.tranC2==0
            options.tranC2 = 1e-5;
        end
        
    case 'enmctran_par_sel'
        saveFile = sprintf('%s%s_%s_nl%d_nUlbl%d_nL%d_run%d.mat',...
            resultDir,dataName,method,nlabel,nUnlabel,...
            nK,idx_run);
        load(saveFile,'bestParam')
        
        tmp_str1 = regexp(bestParam,'C1','split');
        tmp_str2 = regexp(tmp_str1{2},'_','split');
        options.tranC1 = str2num(tmp_str2{1});
        
        tmp_str1 = regexp(bestParam,'C2','split');
        options.tranC2 = str2num(tmp_str1{2});
        
        if options.tranC1==0
            options.tranC1 = 1e-5;
        end
        if options.tranC2==0
            options.tranC2 = 1e-5;
        end
        
    case 'enmctran_par_omp'
        saveFile = sprintf('%s%s_%s_nl%d_nUlbl%d_nL%d_run%d.mat',...
            resultDir,dataName,method,nlabel,nUnlabel,...
            nK,idx_run);
        load(saveFile,'bestParam')
        
        tmp_str1 = regexp(bestParam,'C1','split');
        tmp_str2 = regexp(tmp_str1{2},'_','split');
        options.tranC1 = str2num(tmp_str2{1});

        tmp_str1 = regexp(bestParam,'C2','split');
        options.tranC2 = str2num(tmp_str1{2});
        
        if options.tranC1==0
            options.tranC1 = 1e-5;
        end
        if options.tranC2==0
            options.tranC2 = 1e-5;
        end
        
    case 'enmctran_par_omp_sel'
        saveFile = sprintf('%s%s_%s_nl%d_nUlbl%d_nL%d_run%d.mat',...
            resultDir,dataName,method,nlabel,nUnlabel,...
            nK,idx_run);
        load(saveFile,'bestParam')
        
        tmp_str1 = regexp(bestParam,'C1','split');
        tmp_str2 = regexp(tmp_str1{2},'_','split');
        options.tranC1 = str2num(tmp_str2{1});

        tmp_str1 = regexp(bestParam,'C2','split');
        options.tranC2 = str2num(tmp_str1{2});
        
        if options.tranC1==0
            options.tranC1 = 1e-5;
        end
        if options.tranC2==0
            options.tranC2 = 1e-5;
        end
        
end


