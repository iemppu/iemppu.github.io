function [labeledIndex_l] = bootstrapResample(L, nLabel, label_multi)
% Perform bootstrap on labeled data
%
% forTimes:           # of times for resampling (for-loops)
% L:                  # of times of bootstrap in each resampling (# of Learners/subsets)
% nLabel:             # of labeled data
% label_multi:        labels of labeled data (vector for multiclass; matrix for multi-label)


values = unique(label_multi(label_multi~=0));
K = length(values);
nl_eachClass = ceil(nLabel / K);
labeledIndex_l = zeros(K*nl_eachClass,L);
for c = 1:K
    cIndex = find(label_multi==values(c));
    % if labeled data are not sufficient, we can bootstrap many times
    boot_times = ceil(nLabel / length(cIndex));
    resampleIndex = [];
    for ii = 1:boot_times
        [~,tmp_resampleIndex] = bootstrp(L,[],cIndex);
        resampleIndex = [resampleIndex;tmp_resampleIndex];
    end
    labeledIndex_l((c-1)*nl_eachClass+1:c*nl_eachClass,:) = cIndex(resampleIndex(1:nl_eachClass,:));
end


