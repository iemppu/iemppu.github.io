function [Yu,W,b,nIP] = ASL(Xl, Yl, Xu, r1, inMaxIter)
%%adaptive semi-supervised learning code
%%Xl:  labeled data :nl by d
%%Yl: label matrix, nl by c
%%Xu: Unlabeled data, nu by c
%%Yu_G: ground_truth for unlabeled data, just used for evaluating accuracy
%%r1: regualrization parameter
%%inMaxIter: # of iterations

%%Reference: 
%%De Wang, Feiping Nie, Heng Huang. Large Scale Adaptive Semi-supervised Learning via Unified Inductive and Transductive Model. SIGKDD 2014 (ACM SIGKDD Conference on Knowledge Discovery and Data Mining)
[nl,d] = size(Xl);
[nu] = size(Xu,1);
c=size(Yl,2);
T=eye(c);%label encoding matrix 
Xt = Xl';
XuT=Xu';
H=eye(nl)-(1/nl)*ones(nl);
Hu=eye(nu)-(1/nu)*ones(nu);
XX = Xt*H*Xt';
XY = Xt*H*Yl;
XHu=XuT;
XHt=Xt;
%% initialization
W = (XX + 0.1*eye(d))\XY;
b=mean(Yl-Xl*W);
Yu=zeros(nu,c);
%% Main Code
obj = zeros(inMaxIter, 1);
for iter = 1: inMaxIter
    %fix W;
    pred=Xu*W+repmat(b,nu,1);
    for j=1:c
       v=pred-repmat(T(j,:),nu,1);
       p(:,j)=sum(v.*v,2);%p(i,k)
    end
    if r1==1
        Yu=zeros(nu,c);
        [dumb,idx]=min(p,[],2);
        for i=1:nu
            Yu(i,idx(i))=1;
        end
    else 
    mm=(r1.*p).^(1/(1-r1-eps));
    s0=sum(mm,2);%length(find(isnan(s0)))
    Yu=mm./repmat(s0,1,c);%sum(Yu,2)
%     Yu=p.^(1/(1-r1-eps))./repmat(sum(p.^(1/(1-r1-eps)),2),1,c)
    end
    YuR=Yu.^r1;
    s=sum(YuR,2);%
    S=diag(s);
    SS=sum(s);%[i,j]=find(isnan(Yu))
%%compute intermediate objective
r2=0.1*mean((diag(abs(W))));
    %fix Yu;-----------
    pp=1./(nl+SS);
    Q1=pp*ones(nl,nl);
    Q2=pp*S*ones(nu,nu);
    Q3=pp*ones(nl,nu);%
    Q4=pp*S*ones(nu,nl);
    Ls=S-pp*s*s';%(I-Q2)*S
    C1=XHt*(eye(nl)-Q1)*XHt';
%     C2=XHu*Ls*XHu';
    C2=XHu*(eye(nu)-Q2)*S*XHu';
    C3=-XHt*Q3*S*XHu';
    C4=-XHu*Q4*XHt';
    T1=XHt*(eye(nl)-Q1)*Yl;
    T2=XHu*(eye(nu)-Q2)*YuR;
    T3=-XHt*Q3*YuR;
    T4=-XHu*Q4*Yl;
    C=C1+C2+C3+C4+r2*eye(d);
    TT=T1+T2+T3+T4;
    W=C\TT;
    b=pp*(sum(Yl-Xl*W,1)+sum(YuR-S*Xu*W,1));%b: 1 by c
    Lossl=norm(Yl - Xl*W-repmat(b,nl,1), 'fro')^2;
    pred=Xu*W+repmat(b,nu,1);
    for j=1:c
       v=pred-repmat(T(j,:),nu,1);
       p(:,j)=sum(v.*v,2);
    end
    Lossu=sum(sum(Yu.^r1.*p));
    obj(iter) = Lossl + Lossu+r2*norm(W,'fro').^2;
%     obj1(iter,1) = Lossl + Lossu+r*norm(W,'fro').^2;
end
nIP=length(find(s>0.25)); 
1;