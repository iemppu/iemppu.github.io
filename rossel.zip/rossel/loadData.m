function [fea,gnd] = loadData(dataDir,dataName)

switch dataName
    case 'aloi.scale'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        gnd = gnd + 1;
        % normalize features
        fea = normc(fea);
    case 'aloi100.scale.norm'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'pendigits.all'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        gnd = gnd + 1;
        % normalize features
        fea = normc(fea);
    case 'poker'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        gnd = gnd + 1;
        % normalize features
        fea = normc(fea);
    case 'covtype'
        loadFile = sprintf('%s%s.libsvm.binary.scale',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'segment'
        loadFile = sprintf('%s%s.scale',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'diabetes_scale'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'gisette_scale'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'covtype10000Kernel512'
        loadFile = sprintf('%s%s.mat',dataDir,dataName);
        if exist(loadFile,'file')
            load(loadFile);
        else
            load(sprintf('%scovtype10000.scale01.mat',dataDir))
            fea = full(fea');
            addpath('../compMethods/kmult')
            rank_d = 512;
            kernel = @kernel_gaussian;
            [fea,W] = nystrom(fea,rank_d,kernel);
            save(loadFile,'fea','gnd')
        end
    case 'covtype10000Kernel256'
        loadFile = sprintf('%s%s.mat',dataDir,dataName);
        if exist(loadFile,'file')
            load(loadFile);
        else
            load(sprintf('%scovtype10000.scale01.mat',dataDir))
            fea = full(fea');
            addpath('../compMethods/kmult')
            rank_d = 256;
            kernel = @kernel_gaussian;
            [fea,W] = nystrom(fea,rank_d,kernel);
            save(loadFile,'fea','gnd')
        end
    case 'covtype10000Kernel128'
        loadFile = sprintf('%s%s.mat',dataDir,dataName);
        if exist(loadFile,'file')
            load(loadFile);
        else
            load(sprintf('%scovtype10000.scale01.mat',dataDir))
            fea = full(fea');
            addpath('../compMethods/kmult')
            rank_d = 128;
            kernel = @kernel_gaussian;
            [fea,W] = nystrom(fea,rank_d,kernel);
            save(loadFile,'fea','gnd')
        end
    case 'covtype10000Kernel'
        loadFile = sprintf('%s%s.mat',dataDir,dataName);
        load(loadFile);
    case 'covtype.scale01'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'protein.all'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'usps'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'rcv1_train.multiclass'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        gnd(gnd>44) = gnd(gnd>44) - 1;
        K = length(unique(gnd));
        gap_classes = [];
        for i = 1:K
            sIndex = find(gnd==i);
            if length(sIndex) < 20
                gap_classes = [gap_classes;i];
                fea(sIndex,:) = [];
                gnd(sIndex,:) = [];
            end
        end
        K2 = length(unique(gnd));
        n_gaps = length(gap_classes);
        for i=1:n_gaps
            gap_class = gap_classes(i);
            gnd(gnd>gap_class) = gnd(gnd>gap_class) - 1;
            gap_classes = gap_classes - 1;
        end
        fea = (fea)';
    case 'rcv1_all.multiclass'
        Nthreshold = 500;
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
%         gnd(gnd>44) = gnd(gnd>44) - 1;
        K = length(unique(gnd));
        gap_classes = [];
        for i = 1:K
            sIndex = find(gnd==i);
            if length(sIndex) < Nthreshold
                gap_classes = [gap_classes;i];
                fea(sIndex,:) = [];
                gnd(sIndex,:) = [];
            end
        end
        K2 = length(unique(gnd));
        n_gaps = length(gap_classes);
        for i=1:n_gaps
            gap_class = gap_classes(i);
            gnd(gnd>gap_class) = gnd(gnd>gap_class) - 1;
            gap_classes = gap_classes - 1;
        end
        fea = (fea)';
    case 'rcv1_test.multiclass'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = (fea)';
    case 'sector.scale'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'connect-4'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        gnd = gnd + 2;
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'connect-4-10k'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'news20.scale'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'glass.scale'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'iris.scale'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'letter.scale'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'letter.scale.all'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'mnist.scale'
        loadFile = sprintf('%s%s',dataDir,dataName);
        [gnd,fea] = libsvmread(loadFile);
        gnd = gnd + 1;
        fea = full(fea)';
        % normalize features
        fea = normc(fea);
    case 'satimage_all'
        loadFile = sprintf('%s%s.mat',dataDir,dataName);
        load(loadFile)  % gnd, fea
        if length(gnd) == size(fea,1)
            fea = fea';
        end
        % normalize features
        fea = normc(fea);
    case 'mnist8m-10k'
        loadFile = sprintf('%s%s.mat',dataDir,dataName);
        load(loadFile)  % gnd, fea
        gnd = gnd + 1;
        if length(gnd) == size(fea,1)
            fea = fea';
        end
        % normalize features
        fea = normc(fea);
    case 'mnist8m-100k'
        loadFile = sprintf('%s%s.mat',dataDir,dataName);
        load(loadFile)  % gnd, fea
        gnd = gnd + 1;
        if length(gnd) == size(fea,1)
            fea = fea';
        end
        % normalize features
        fea = normc(fea);
    otherwise
        loadFile = sprintf('%s%s.mat',dataDir,dataName);
        load(loadFile)  % gnd, fea
        if length(gnd) == size(fea,1)
            fea = fea';
        end
        % normalize features
        fea = normc(fea);
end

classes = unique(gnd);
K = length(classes);
aa=1;