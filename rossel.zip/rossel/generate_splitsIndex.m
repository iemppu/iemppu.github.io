function [labeledIndex,unlabeledIndex,testIndex,K] = generate_splitsIndex(gnd,dataset,idx_run)
% random sample labeled, unlabeled and test data (THREE parts)

splitDir = dataset.splitDir;
dataName = dataset.dataName;
num_labeledIndex_perClass = dataset.num_labeledIndex_perClass;
num_unlabeledIndex = dataset.num_unlabeledIndex;
num_testIndex = dataset.num_testIndex;

% ----------------- Load split training & testing indices -----------------
% The format of indices
%       labeledIndex: n1 * 1
%       unlabeledIndex: n2 * 1, where n1+n2=n
%       testIndex: test_n * 1
%       K: the number of classes

if length(dataName)>13
prefix_dataName = dataName(1:13);
switch prefix_dataName
    case 'covtype10000K'
        dataName = 'covtype10000.scale01';
end
end

tr_te_splitFile = sprintf('%s%s_nlpc%d_nul%d_te%d_run%d.mat',...
    splitDir,dataName,num_labeledIndex_perClass,...
    num_unlabeledIndex,num_testIndex,idx_run);

if exist(tr_te_splitFile,'file')
    load(tr_te_splitFile)
else % - Sample the indices randomly and save it
    values = unique(gnd);
    K = length(values);
    aa = hist(gnd,K);
    not_enough_index = find(aa <= num_labeledIndex_perClass);  % if not enough samples
    enough_index = find(aa > num_labeledIndex_perClass);  % if not enough samples
    num_labeledIndex_perClasses = repmat(num_labeledIndex_perClass,K,1);
    num_labeledIndex_perClasses(not_enough_index) = aa(not_enough_index)/2;
    % First sample the labeled indices
    labeledIndex = [];
    for c=1:K
        cIndex = find(gnd(:)==values(c));
        randIndex = randperm(length(cIndex));
        labeledIndex = [labeledIndex(:); cIndex(randIndex(1:num_labeledIndex_perClasses(c)))];
    end
    % Then sample the unlabeled & test indices
    restIndex = setdiff(1:length(gnd),labeledIndex(:));
    randIndex = randperm(length(restIndex));
    unlabeledIndex = restIndex(randIndex(1:num_unlabeledIndex));
    if num_unlabeledIndex+num_testIndex <= length(restIndex)
        testIndex = restIndex(randIndex(num_unlabeledIndex+1:num_unlabeledIndex+num_testIndex));
    else
        testIndex = restIndex(randIndex(num_unlabeledIndex+1:end));
    end
    save(tr_te_splitFile,'labeledIndex','unlabeledIndex','testIndex','K')
end



