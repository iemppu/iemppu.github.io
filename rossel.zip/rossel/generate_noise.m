function [gnd_labeled,resultDir] = generate_noise(gnd_labeled,splitDir,dataName,...
    nlabel,nUnlabel,idx_run,noiseRatio)

gnd_labeled_bk = gnd_labeled;

resultDir = sprintf('result_addAllsel_noise%0.3f/',noiseRatio);
if ~exist(resultDir,'dir')
    system(sprintf('mkdir %s',resultDir));
end
noiseLabFile = sprintf('%snoise/%s_nl%d_nun%d_run%d_nRatio%0.2f.mat',...
    splitDir,dataName,nlabel,nUnlabel,idx_run,noiseRatio);
if exist(noiseLabFile,'file')
    load(noiseLabFile)
else
    LL = length(gnd_labeled);
    ri = randperm(LL);
    gnd_noise = gnd_labeled(ri(1:ceil(noiseRatio*LL)));
    gnd_noise_bk = gnd_noise;
    rv = unique(gnd_labeled);
    kk = length(rv);
    for iik=1:kk
        k = rv(iik);
        sindex = find(k==gnd_noise_bk);
        value_can_assign = setdiff(unique(gnd_labeled),k);
        randsamp = randi(length(value_can_assign),length(sindex),1);
        gnd_noise2 = value_can_assign(randsamp);
        gnd_noise(sindex) = gnd_noise2;
    end
    gnd_labeled(ri(1:ceil(noiseRatio*LL))) = gnd_noise;
    save(noiseLabFile,'gnd_noise','gnd_noise_bk','gnd_labeled')
end
