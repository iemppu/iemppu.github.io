function [activeSet_C] = genActive(labeled_label_multi,initLabMat,otherLabMat)
% Add active sets for each class
% labeled_label_multi:     label vec/mat of labeled data
% initLabMat:              predicted unlabeled label matrix by all labeled data
% otherLabMat:             predicted unlabeled label matrix by learners
% selectedKernelIndex:     a list ranking similarity of labeling kernels

num_class = length(unique(labeled_label_multi));
% PP is the label matrix for entire labeled data
if num_class>2
    PP = (repmat(labeled_label_multi,1,num_class)==repmat(1:num_class,length(labeled_label_multi),1))';
    PP = PP*2-1;
else
    PP = labeled_label_multi(:)';
end

% Initialize the active set
% **activeSet_C{l} is the active set of l-th learner
% Update probability matrix & transform probability matrix to label matrix
% Add ONE probability matrices into the active set of each learner
if num_class>2
    activeSet_C = cell(num_class,1);
else
    activeSet_C = cell(num_class-1,1);
end

%% Label kernels of [full annotators]
tY = [PP,initLabMat]; % here initLabMat is only the labels of unlabeled data
if num_class>2
    for c = 1:num_class
        activeSet_C{c} = []; % initialize active set
        activeSet_C{c} = [activeSet_C{c},tY(c,:)'];
    end
%         activeSet_C{l,c} = [activeSet_C{l,c};initLabMat(c,unlabeledIndex_l(:,l))*2-1];
else
    c = num_class-1;
    activeSet_C{c} = [];
    activeSet_C{c} = [activeSet_C{c},tY(c,:)'];
end

%% Label kernels of weak annotators
for i = 1:length(otherLabMat)
    % add
    if num_class>2
        % compute prediction labeling tY
        tY = [PP,otherLabMat{i}];
        for c = 1:num_class
            activeSet_C{c} = [activeSet_C{c},tY(c,:)'];
        end
    else
        % compute prediction labeling tY
        tY = [PP,otherLabMat{i}];
        c = num_class-1;
        activeSet_C{c} = [activeSet_C{c},tY(c,:)'];
    end
end