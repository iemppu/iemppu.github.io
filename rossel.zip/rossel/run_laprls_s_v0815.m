% This is the experiment script for multiclass transduction learning
function run_laprls_s_v0815(dataName,nlabel,nUnlabel,runs)

do_best = 0;

addpath('../compMethods/MR/')
addpath('../compMethods/MR/libsvm-3.20/matlab')  % by yanyan: will use libsvm

method = 'laprls_s';
%dataDir = 'data';
dataDir = '../datasets/';
splitDir = 'split/';
resultDir = 'result_addAllsel/';
resultDir_bk = resultDir;
resultDir_best = sprintf('%sbest/',resultDir);

%   "options" structure is as follows:
%
%            Field Name:  Description                                         : default 
% -------------------------------------------------------------------------------------
%              'Kernel':  'linear' | 'rbf' | 'poly'                           : 'linear'
%         'KernelParam':  --    | sigma | degree                              :  1 
%                  'NN':  number of nearest neighbor                          :  6
%'GraphDistanceFuncion':  distance function for graph: 'euclidean' | 'cosine' : 'euclidean' 
%        'GraphWeights':  'binary' | 'distance' | 'heat'                      : 'binary'
                               % by yanyan: No 'distance' in their fucntion
%    'GraphWeightParam':  e.g For heat kernel, width to use                   :  1 
%      'GraphNormalize':  Use normalized Graph laplacian (1) or not (0)       :  1
%          'ClassEdges':  Disconnect Edges across classes:yes(1) no (0)       :  0
%             'gamma_A':  RKHS norm regularization parameter (Ambient)        :  1 
%             'gamma_I':  Manifold regularization parameter  (Intrinsic)      :  1    
%                   mu':  Class-based Fully Supervised Laplacian Parameter    : 0.5
%   'LaplacianDegree'  :  Degree of Iterated Laplacian                        :  1  
%                   k  :  Regularized Spectral Representation Paramter        :  2
% -------------------------------------------------------------------------------------
% para_dataFile = {'covtype1500'};
% dataName = 'dna_all';
% nlabel = 15;
% para_nUnlabel = 4000;
para_nUnlabel = nUnlabel;

% runs = [1];

% para_Kernel = {'linear','rbf','poly'};
para_Kernel = {'rbf'}; % rbf is the same for every methods
para_KernelPara = [1]; % KP is the same for every methods
para_NN = [5];
% para_graphDistFunc = {'euclidean','cosine'};
% para_graphWeights = {'binary','heat'};
para_graphDistFunc = {'euclidean'};
para_graphWeights = {'heat'};
para_graphWeightParam = [1];
para_graphNorm = [1];
para_classEdges = [0];
% para_gammaA = [1e-5,1e-4,1e-3,1e-2,1e-1,1e+0,1e+1,1e+2,1e+3,1e+4,1e+5];
% para_gammaI = [1e-5,1e-4,1e-3,1e-2,1e-1,1e+0,1e+1,1e+2,1e+3,1e+4,1e+5];
switch dataName
    case 'covtype10000.scale01'
        para_gammaA = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3,1e+5];
        para_gammaI = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3,1e+5];
    case 'connect-4-10k'
        para_gammaA = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3,1e+5];
        para_gammaI = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3,1e+5];
    case 'rcv1_all.multiclass'  % rcv1_all.mutliclass: out-of-memory
        para_gammaA = [1e-1];
        para_gammaI = [1e-5];
    otherwise
        para_gammaA = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3,1e+5];
        para_gammaI = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3,1e+5];
end

para_mu = [0.5];
para_LaplacianDegree = [1];
para_k = [2];


    
        
%% ------------------- Load data and groundtruth labels -------------------
% NOTE: fea, X (or sth else) should be matrices with row vectors
[fea,gnd] = loadData(dataDir,dataName);

for idx_run=runs
    
if do_best  % in this mode, we do not want to tune para
    optFile = sprintf('%s%s_lapsvm_nl%d_nun%d_run%d.mat',...
        resultDir_bk,dataName,nlabel,nUnlabel,idx_run);
    load(optFile,'bestOptions_laprlsc')
    
    para_Kernel = {bestOptions_laprlsc.Kernel};
    para_KernelParam = bestOptions_laprlsc.KernelParam;
    para_NN = bestOptions_laprlsc.NN;
    para_graphDistFunc = {bestOptions_laprlsc.GraphDistanceFunction};
    para_graphWeights = {bestOptions_laprlsc.GraphWeights};
    para_graphWeightParam = bestOptions_laprlsc.GraphWeightParam;
    para_graphNorm = bestOptions_laprlsc.GraphNormalize;
    para_classEdges = bestOptions_laprlsc.ClassEdges;
    para_gammaA = bestOptions_laprlsc.gamma_A;
    para_gammaI = bestOptions_laprlsc.gamma_I;
    para_mu = bestOptions_laprlsc.mu;
    para_LaplacianDegree = bestOptions_laprlsc.LaplacianDegree;
    para_k = bestOptions_laprlsc.k;
    
    resultDir = resultDir_best;
    if ~exist(resultDir,'dir')
        system(sprintf('mkdir %s',resultDir));
    end
end

%% generate split index
dataset.splitDir = splitDir;
dataset.dataName = dataName;
dataset.num_labeledIndex_perClass = ceil(nlabel/max(gnd));
dataset.num_labeledIndex = dataset.num_labeledIndex_perClass*max(gnd);
dataset.num_unlabeledIndex = para_nUnlabel;
dataset.num_testIndex = size(gnd,1)-dataset.num_labeledIndex-dataset.num_unlabeledIndex;

[labeledIndex,unlabeledIndex,testIndex,K] = ...
    generate_splitsIndex(gnd,dataset,idx_run);

X_labeled = fea(:,labeledIndex);
X_unlabeled = fea(:,unlabeledIndex);
X = [X_labeled,X_unlabeled];
X_test = fea(:,testIndex);

gnd_labeled = gnd(labeledIndex,:);
gnd_test = gnd(testIndex,:);

n_labeled = size(X_labeled,2);
n_test = size(X_test,2);


% test liblinear
addpath('/home/yayan/src/liblinear-1.96/matlab/')
best_acc_liblinear = 0;
para_lib_s = [1:4];
para_lib_c = [1e-5,1e-4,1e-3,1e-2,1e-1,1e+0,1e+1,1e+2,1e+3,1e+4,1e+5];
for idx_lib_s=1:length(para_lib_s)
    lib_s = para_lib_s(idx_lib_s);
for idx_lib_c=1:length(para_lib_c)
    lib_c = para_lib_c(idx_lib_c);
liboptions = sprintf('-q -s %d -c %f',lib_s,lib_c);
libm = train(gnd_labeled,sparse(X_labeled),liboptions,'col');
[lib_pred,lib_acc,lib_dv] = predict(gnd_test,sparse(X_test),libm,'-q','col');
fprintf('liblinear acc = %0.4f | s=%d | c=%f\n',lib_acc(1),lib_s,lib_c)
if best_acc_liblinear < lib_acc(1)
    best_acc_liblinear = lib_acc(1);
    best_para_liblinear = sprintf('s%d_c%0.5f',lib_s,lib_c);
end
end % liblinear_c
end % liblinear_s

%% construct label_multi
label_multi = [gnd_labeled; gnd(unlabeledIndex,:)];
% label_multi = [gnd_labeled; zeros(size(X_unlabeled,2),1)];

numbers = hist(label_multi(1:n_labeled),0:K);
base = sum(numbers(1+1:K+1)); % do not consider 0 (unlabeled data)
for c = 1:K
    options.lr(c) = numbers(1+c) / base;
end


bestAcc_laprls = 0;
bestAcc_laprlsc = 0;
bestOptions_laprls = [];
bestOptions_laprls = [];
bestOutTime_laprls = 0;
bestOutTime_laprls = 0;


for idx_kernel=1:length(para_Kernel)
for idx_kernelPara=1:length(para_KernelPara)
for idx_NN=1:length(para_NN)
for idx_graphDistFunc=1:length(para_graphDistFunc)
for idx_graphWeights=1:length(para_graphWeights)
for idx_graphWeightParam=1:length(para_graphWeightParam)
for idx_graphNorm=1:length(para_graphNorm)
for idx_classEdges=1:length(para_classEdges)
for idx_gammaA=1:length(para_gammaA)
for idx_gammaI=1:length(para_gammaI)
for idx_mu=1:length(para_mu)
for idx_LapacianDegree=1:length(para_LaplacianDegree)
for idx_k=1:length(para_k)



% ---------------------------- Set parameters ----------------------------
%   "options" structure is as follows:
%
%            Field Name:  Description                                         : default 
% -------------------------------------------------------------------------------------
%              'Kernel':  'linear' | 'rbf' | 'poly'                           : 'linear'
%         'KernelParam':  --    | sigma | degree                              :  1 
%                  'NN':  number of nearest neighbor                          :  6
%'GraphDistanceFuncion':  distance function for graph: 'euclidean' | 'cosine' : 'euclidean' 
%        'GraphWeights':  'binary' | 'distance' | 'heat'                      : 'binary'
%    'GraphWeightParam':  e.g For heat kernel, width to use                   :  1 
%      'GraphNormalize':  Use normalized Graph laplacian (1) or not (0)       :  1
%          'ClassEdges':  Disconnect Edges across classes:yes(1) no (0)       :  0
%             'gamma_A':  RKHS norm regularization parameter (Ambient)        :  1 
%             'gamma_I':  Manifold regularization parameter  (Intrinsic)      :  1    
%                   mu':  Class-based Fully Supervised Laplacian Parameter    : 0.5
%   'LaplacianDegree'  :  Degree of Iterated Laplacian                        :  1  
%                   k  :  Regularized Spectral Representation Paramter        :  2
% -------------------------------------------------------------------------------------
options.Kernel = para_Kernel{idx_kernel};
options.KernelParam = para_KernelPara(idx_kernelPara);
options.NN = para_NN(idx_NN);
options.GraphDistanceFunction = para_graphDistFunc{idx_graphDistFunc};
options.GraphWeights = para_graphWeights{idx_graphWeights};
options.GraphWeightParam = para_graphWeightParam(idx_graphWeightParam);
options.GraphNormalize = para_graphNorm(idx_graphNorm);
options.ClassEdges = para_classEdges(idx_classEdges);
options.gamma_A = para_gammaA(idx_gammaA);
options.gamma_I = para_gammaI(idx_gammaI);
options.mu = para_mu(idx_mu);
options.LaplacianDegree = para_LaplacianDegree(idx_LapacianDegree);
options.k = para_k(idx_k);

dataset.X = X';
dataset.Y = label_multi;
% dataset.Y = gnd_labeled;
dataset.Xt = X_test';
dataset.Yt = gnd_test;
% dataset.idxLabs = find(label_multi~=0)';
dataset.idxLabs = 1:length(gnd_labeled);
% ---------------------- run multiclass transduction ----------------------
% X: dim * n, training data, where n is the number of samples
% X_test: dim * m, testing data, where n is the number samples
% label_multi: 0 for test data, 1, 2, ..., n_f for training data
t0 = clock;
result = laprls_yan(dataset,options);
t1 = clock;
outTime = etime(t1,t0);

[~,frlsc_t]=max(result.frlsc_t,[],2);
accuracy_laprlsc = length(find(frlsc_t == gnd_test))/length(gnd_test);
% [~,frlsc_t]=max(result.frlsc_t,[],2);
% accuracy_laprlsc = length(find(frlsc_t == gnd_test))/length(gnd_test);

% save([resultDir,para_dataFile{idx_dataFile},'_LapSVM',...
%         '_nl',num2str(para_num_labeledIndex_perClass(idx_num_labeledIndex_perClass)),...
%         '_nu',num2str(para_num_unlabeledIndex(idx_num_unlabeledIndex)),...
%         '_nt',num2str(para_num_testIndex(idx_num_testIndex)),...
%         '_K_',num2str(para_Kernel{idx_kernel}),...
%         '_Kpara',num2str(para_KernelPara(idx_kernelPara)),...
%         '_NN',num2str(para_NN(idx_NN)),...
%         '_dist_',num2str(para_graphDistFunc{idx_graphDistFunc}),...
%         '_gWeight_',num2str(para_graphWeights{idx_graphWeights}),...
%         '_gWPara',num2str(para_graphWeightParam(idx_graphWeightParam)),...
%         '_gNorm',num2str(para_graphNorm(idx_graphNorm)),...
%         '_CE',num2str(para_classEdges(idx_classEdges)),...
%         '_gA',num2str(para_gammaA(idx_gammaA)),...
%         '_gI',num2str(para_gammaI(idx_gammaI)),...
%         '_mu',num2str(para_mu(idx_mu)),...
%         '_Deg',num2str(para_LaplacianDegree(idx_LapacianDegree)),...
%         '_k',num2str(para_k(idx_k)),...
%         '.mat'],'result','accuracy_svm','accuracy_rlsc','outTime')

out_text = sprintf('laprls =%0.4f: %0.4fs | nl%d_nUn%d_run%d_NN%d_gwp%f_gN%d_cE%d_gA%f_gI%f_mu%f_LD%f_k%f\n',...
    accuracy_laprlsc,outTime,nlabel,dataset.num_unlabeledIndex,idx_run,options.NN,...
    options.GraphWeightParam,options.GraphNormalize,options.ClassEdges,options.gamma_A,...
    options.gamma_I,options.mu,options.LaplacianDegree,options.k);
fprintf(out_text);

% out_text = sprintf('laprlsc=%0.4f: %0.4fs | nl%d_nUn%d_run%d_NN%d_gwp%f_gN%d_cE%d_gA%f_gI%f_mu%f_LD%f_k%f\n',...
%     accuracy_laprlsc,outTime,nlabel,dataset.num_unlabeledIndex,idx_run,options.NN,...
%     options.GraphWeightParam,options.GraphNormalize,options.ClassEdges,options.gamma_A,...
%     options.gamma_I,options.mu,options.LaplacianDegree,options.k);
% fprintf(out_text);

if bestAcc_laprls < accuracy_laprlsc
    bestAcc_laprls = accuracy_laprlsc;
	bestOptions_laprls = options;
    bestOutTime_laprls = outTime;
end
% if bestAcc_laprlsc < accuracy_laprlsc
%     bestAcc_laprlsc = accuracy_laprlsc;
%     bestOptions_laprlsc = options;
%     bestOutTime_laprlsc = outTime;
% end

end % k: fix as 2
end % LaplacianDegree: fix as 1
end % mu: fix as 0.5
end % gammaI
end % gammaA
end % classEdges: fix as 0
end % graphNorm: fix as 1
end % graphWeightParam: fix as 1
end % graphWeight: fix as heat
end % graphDistFunc: fix as euclidean
end % NN
end % KernelPara: fix as 1
end % Kernel: fix as rbf

saveFile = sprintf('%s%s_%s_nl%d_nun%d_run%d.mat',...
            resultDir,dataName,method,nlabel,dataset.num_unlabeledIndex,idx_run);
% save(saveFile,'bestAcc_laprlsc','bestAcc_lapsvm','bestOptions_laprlsc','bestOptions_lapsvm',...
%     'best_acc_liblinear','best_para_liblinear','bestOutTime_lapsvm',...
%     'bestOutTime_laprlsc')
% save(saveFile,'bestAcc_lapsvm','bestOptions_lapsvm',...
%     'best_acc_liblinear','best_para_liblinear','bestOutTime_lapsvm')
save(saveFile,'bestAcc_laprls','bestOptions_laprls',...
    'best_acc_liblinear','best_para_liblinear','bestOutTime_laprls')

end % idx_run