% This script reads the results and plot

resultDir = 'result_ssl';

% dataNames = {'connect-4','covtype10000.scale01','rcv1_train.multiclass','sector.scale','segment','usps',''};
% dataName = dataNames{dataID};
dataName = 'dna_all';

% methodNames = {'enmctran_par_sel','enmctran_par_omp_sel',...
%     'enmctran_par','enmctran_par_omp','liblinear',...
%     'libsvm','libsvm_ovr','libsvm_en','liblinear_en','libsvm_en_ovr',...
%     'enmctran_par_libsvm',...
%     'lapsvm_s','laprls_s','asl','cs4vm','means3vm'};
% methodNames = {'lapsvm'};
methodNames = {...
    'enmctran_par','liblinear',...
    'libsvm','libsvm_ovr','libsvm_en','libsvm_en_ovr','liblinear_en',...
    'lapsvm_s','laprls_s','asl','cs4vm','means3vm'};

methodNames = {'rossel','liblinear'};

nl = 159;

nLs = [5,10:10:50];
nLs_en = [10,50];

nUlbl = 2400;

runs = 1:10;

for idx_methodNames=1:length(methodNames)
    methodName = methodNames{idx_methodNames};
    switch methodName
        case 'enmctran_par'
            for idx_nL = 1:length(nLs)
                accs = [];
                outTimes = [];
                nL = nLs(idx_nL);
                for run=runs
                    fileName = sprintf('%s/%s_%s_nl%d_nUlbl%d_nL%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,nL,run);
                    load(fileName,'bestAcc_enmctran')
                    accs = [accs;bestAcc_enmctran];
                    load(fileName,'bestOutTime')
                    load(fileName,'outTime_pre')
                    outTimes = [outTimes;bestOutTime+outTime_pre];
                end
                fprintf('%s: %s_nK%d=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,nL,mean(accs),std(accs),mean(outTimes),std(outTimes))
            end
        case 'rossel'
            for idx_nL = 1:length(nLs)
                accs = [];
                outTimes = [];
                nL = nLs(idx_nL);
                for run=runs
                    fileName = sprintf('%s/%s_%s_nl%d_nUlbl%d_nL%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,nL,run);
                    load(fileName,'bestAcc_enmctran')
                    accs = [accs;bestAcc_enmctran];
                    load(fileName,'bestOutTime')
                    load(fileName,'outTime_preprocess')
                    outTimes = [outTimes;bestOutTime+outTime_preprocess];
                end
                fprintf('%s: %s_nK%d=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,nL,mean(accs),std(accs),mean(outTimes),std(outTimes))
            end
        case 'enmctran_par_libsvm'
            for idx_nL = 1:length(nLs)
                accs = [];
                outTimes = [];
                nL = nLs(idx_nL);
                for run=runs
                    fileName = sprintf('%s/%s_%s_nl%d_nUlbl%d_nL%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,nL,run);
                    load(fileName,'bestAcc_enmctran')
                    accs = [accs;bestAcc_enmctran];
                    load(fileName,'bestOutTime')
                    load(fileName,'outTime_pre')
                    outTimes = [outTimes;bestOutTime+outTime_pre];
                end
                fprintf('%s: %s_nK%d=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,nL,mean(accs),std(accs),mean(outTimes),std(outTimes))
            end
        case 'enmctran_par_sel'
            for idx_nL = 1:length(nLs)
                accs = [];
                outTimes = [];
                nL = nLs(idx_nL);
                for run=runs
                    fileName = sprintf('%s/%s_%s_nl%d_nUlbl%d_nL%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,nL,run);
                    load(fileName,'bestAcc_enmctran')
                    accs = [accs;bestAcc_enmctran];
                    load(fileName,'bestOutTime')
                    load(fileName,'outTime_pre')
                    outTimes = [outTimes;bestOutTime+outTime_pre];
                end
                fprintf('%s: %s_nK%d=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,nL,mean(accs),std(accs),mean(outTimes),std(outTimes))
            end
        case 'enmctran_par_omp_sel'
            for idx_nL = 1:length(nLs)
                accs = [];
                outTimes = [];
                nL = nLs(idx_nL);
                for run=runs
                    fileName = sprintf('%s/%s_%s_nl%d_nUlbl%d_nL%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,nL,run);
                    load(fileName,'bestAcc_enmctran')
                    accs = [accs;bestAcc_enmctran];
                    load(fileName,'bestOutTime')
                    load(fileName,'outTime_pre')
                    outTimes = [outTimes;bestOutTime+outTime_pre];
                end
                fprintf('%s: %s_nK%d=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,nL,mean(accs),std(accs),mean(outTimes),std(outTimes))
            end
        case 'enmctran_par_omp'
            for idx_nL = 1:length(nLs)
                accs = [];
                outTimes = [];
                nL = nLs(idx_nL);
                for run=runs
                    fileName = sprintf('%s/%s_%s_nl%d_nUlbl%d_nL%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,nL,run);
                    load(fileName,'bestAcc_enmctran')
                    accs = [accs;bestAcc_enmctran];
                    load(fileName,'bestOutTime')
                    load(fileName,'outTime_pre')
                    outTimes = [outTimes;bestOutTime+outTime_pre];
                end
                fprintf('%s: %s_nK%d=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,nL,mean(accs),std(accs),mean(outTimes),std(outTimes))
            end
        case 'enmctranWellsvm'
            accs = [];
            outTimes = [];
            for run=runs
                fileName = sprintf('%s/%s_%s_nl%d_nUlbl%d_nL%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,nL,run);
                load(fileName,'bestAcc_enmctran')
                accs = [accs;bestAcc_enmctran];
                load(fileName,'bestOutTime')
                outTimes = [outTimes;bestOutTime];
            end
            fprintf('%s: %s=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,mean(accs),std(accs),mean(outTimes),std(outTimes))
        case 'liblinear2'
            accs = [];
            outTimes = [];
            for run=runs
                fileName = sprintf('%s/%s_%s_nl%d_nUlbl%d_nL%d_run%d.mat',resultDir,dataName,'enmctran_par',nl,nUlbl,5,run);
                load(fileName,'best_acc_liblinear')
                accs = [accs;best_acc_liblinear];
                load(fileName,'bestOutTime')
                outTimes = [outTimes;bestOutTime];
            end
            fprintf('%s: %s=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,mean(accs),std(accs),mean(outTimes),std(outTimes))
        case 'liblinear'
            accs = [];
            outTimes = [];
            for run=runs
                fileName = sprintf('%s/%s_%s_nl%d_nUlbl%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,run);
                load(fileName,'best_acc_liblinear')
                accs = [accs;best_acc_liblinear];
                load(fileName,'bestOutTime_liblinear')
                outTimes = [outTimes;bestOutTime_liblinear];
            end
            if mean(accs)>=1
                accs = accs/100;
            end
            fprintf('%s: %s=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,mean(accs),std(accs),mean(outTimes),std(outTimes))
        case 'libsvm'
            accs = [];
            outTimes = [];
            for run=runs
                fileName = sprintf('%s/%s_%s_nl%d_nUlbl%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,run);
                load(fileName,'best_acc_libsvm')
                accs = [accs;best_acc_libsvm];
                load(fileName,'bestOutTime_libsvm')
                outTimes = [outTimes;bestOutTime_libsvm];
            end
            if mean(accs)>=1
                accs = accs/100;
            end
            fprintf('%s: %s=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,mean(accs),std(accs),mean(outTimes),std(outTimes))
        case 'libsvm_ovr'
            accs = [];
            outTimes = [];
            for run=runs
                fileName = sprintf('%s/%s_%s_nl%d_nUlbl%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,run);
                load(fileName,'best_acc_libsvm')
                accs = [accs;best_acc_libsvm];
                load(fileName,'bestOutTime_libsvm')
                outTimes = [outTimes;bestOutTime_libsvm];
            end
            if mean(accs)>=1
                accs = accs/100;
            end
            fprintf('%s: %s=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,mean(accs),std(accs),mean(outTimes),std(outTimes))
        case 'libsvm_en_ovr'
            outTimes = [];
            for idx_nL=1:length(nLs_en)
                nL = nLs_en(idx_nL);
                accs = [];
                for run=runs
                    fileName = sprintf('%s/%s_%s_nl%d_nUlbl%d_nK%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,nL,run);
                    load(fileName,'best_acc_libsvm_en')
                    accs = [accs;best_acc_libsvm_en];
                    load(fileName,'bestOutTime_libsvm_en')
                    outTimes = [outTimes;bestOutTime_libsvm_en];
                end
                fprintf('%s: %s_nK%d=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,nL,mean(accs),std(accs),mean(outTimes),std(outTimes))
            end
        
        case 'libsvm_en'
            outTimes = [];
            for idx_nL=1:length(nLs_en)
                nL = nLs_en(idx_nL);
                accs = [];
                for run=runs
                    fileName = sprintf('%s/%s_%s_nl%d_nUlbl%d_nK%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,nL,run);
                    load(fileName,'best_acc_libsvm_en')
                    accs = [accs;best_acc_libsvm_en];
                    load(fileName,'bestOutTime_libsvm_en')
                    outTimes = [outTimes;bestOutTime_libsvm_en];
                end
                fprintf('%s: %s_nK%d=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,nL,mean(accs),std(accs),mean(outTimes),std(outTimes))
            end
        
        case 'liblinear_en'
            outTimes = [];
            for idx_nL=1:length(nLs_en)
                nL = nLs_en(idx_nL);
                accs = [];
                for run=runs
                    fileName = sprintf('%s/%s_%s_nl%d_nUlbl%d_nK%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,nL,run);
                    load(fileName,'best_acc_libsvm_en')
                    accs = [accs;best_acc_libsvm_en];
                    load(fileName,'bestOutTime_libsvm_en')
                    outTimes = [outTimes;bestOutTime_libsvm_en];
                end
                fprintf('%s: %s_nK%d=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,nL,mean(accs),std(accs),mean(outTimes),std(outTimes))
            end
        case 'lapsvm'
            accs = [];
            outTimes = [];
            for run=runs
                fileName = sprintf('%s/%s_%s_nl%d_nun%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,run);
                load(fileName,'bestAcc_lapsvm')
                accs = [accs;bestAcc_lapsvm];
                load(fileName,'bestOutTime_lapsvm')
                outTimes = [outTimes;bestOutTime_lapsvm];
            end
            fprintf('%s: %s=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,mean(accs),std(accs),mean(outTimes),std(outTimes))
        case 'lapsvm_s'
            accs = [];
            outTimes = [];
            for run=runs
                fileName = sprintf('%s/best/%s_%s_nl%d_nun%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,run);
                load(fileName,'bestAcc_lapsvm')
                accs = [accs;bestAcc_lapsvm];
                load(fileName,'bestOutTime_lapsvm')
                outTimes = [outTimes;bestOutTime_lapsvm];
            end
            fprintf('%s: %s=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,mean(accs),std(accs),mean(outTimes),std(outTimes))
        case 'laprls_s'
            accs = [];
            outTimes = [];
            for run=runs
                fileName = sprintf('%s/best/%s_%s_nl%d_nun%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,run);
                load(fileName,'bestAcc_laprls')
                accs = [accs;bestAcc_laprls];
                load(fileName,'bestOutTime_laprls')
                outTimes = [outTimes;bestOutTime_laprls];
            end
            fprintf('%s: %s=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,mean(accs),std(accs),mean(outTimes),std(outTimes))
        case 'asl'
            accs = [];
            outTimes = [];
            for run=runs
                fileName = sprintf('%s/%s_%s_nl%d_nun%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,run);
                load(fileName,'bestAcc_asl')
                accs = [accs;bestAcc_asl];
                load(fileName,'bestOutTime')
                outTimes = [outTimes;bestOutTime];
            end
            fprintf('%s: %s=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,mean(accs),std(accs),mean(outTimes),std(outTimes))
        case 'cs4vm'
            accs = [];
            outTimes = [];
            for run=runs
                fileName = sprintf('%s/%s_%s_nl%d_nun%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,run);
                load(fileName,'bestAcc_cs4vm')
                accs = [accs;bestAcc_cs4vm];
                load(fileName,'bestOutTime')
                outTimes = [outTimes;bestOutTime];
            end
            fprintf('%s: %s=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,mean(accs),std(accs),mean(outTimes),std(outTimes))
        case 'means3vm'
            accs = [];
            outTimes = [];
            for run=runs
                fileName = sprintf('%s/%s_%s_nl%d_nun%d_run%d.mat',resultDir,dataName,methodName,nl,nUlbl,run);
                load(fileName,'bestAcc_means3vm')
                accs = [accs;bestAcc_means3vm];
                load(fileName,'bestOutTime')
                outTimes = [outTimes;bestOutTime];
            end
            fprintf('%s: %s=%0.4f(%0.4f) | %0.4f(%0.4f) seconds\n',dataName,methodName,mean(accs),std(accs),mean(outTimes),std(outTimes))
    end
    
end

