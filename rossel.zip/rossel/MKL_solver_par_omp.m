function [acc,models] = MKL_solver_par_omp(activeSet_C,X,labsize,X_test,gnd_test,options)
% Perform MKL to solve the problem (OpenMP verison, under construction)
% activeSet_C:   Label kernels
% X:             dim*(n_labeled+n_unlabeled), feature matrix of training data
% X_test:        dim*n_test, feature matrix of testing data
% options:       tranC1, tranC2, lr
%
% map:           mean average precision
% acc:           accuracy
% tmp_alpha:     dual variable alpha
% tmp_sigma:     base kernel coefficient
% tmp_w:         weight

dim = size(X,1);
n_test = size(X_test,2);

num_class = length(unique((gnd_test)));
if num_class==2
    num_class = 1;
end




t_y = ones(size(X,2),1);

y_set = activeSet_C{1};


% Multiple label-kernel learning
liblinear_options = ['-s 3 -c ' num2str(options.tranC1) ' -B -1'];
t_w = zeros(1,dim*size(y_set,2));
t_alpha = zeros(1,size(X,2));
t_sigma = ones(size(y_set,2),1)/size(y_set,1);


t0 = clock;

models = rossel_paromp(t_y,sparse(X'),liblinear_options,size(activeSet_C{end},2),activeSet_C,t_sigma,t_w,t_alpha,options.tranC2,labsize);
%     models = Mctran6_omppar_ssl(t_y,sparse(X'),liblinear_options,size(activeSet_C{end},2),activeSet_C,t_sigma,t_w,t_alpha,options.tranC2,labsize);


t1 = clock;
outTime_well = etime(t1,t0);

%% Predict on entire test data and compute accuracy
pred_decVal1 = zeros(num_class,n_test);
for c = 1:num_class
    %     pred_decVal1(c,:) = prediction_func(tmp_alpha{c},activeSet_C{c}',tmp_sigma{c},X,X_test);
    pred_decVal1(c,:) = prediction_func(models{c}.alpha,activeSet_C{c}',models{c}.sigma,X,X_test);
end


if num_class>2
    % ***** Start computing accuracy *****
    
    % Use the original decision values
    [~,pred_test_label5] = max(pred_decVal1,[],1);
    tmp_acc5 = (length(find(gnd_test == pred_test_label5'))) / length(gnd_test);
    acc = tmp_acc5;
    
else  % if K<=2
    
    pred_test_label5 = sign(pred_decVal1);
    tmp_acc5 = (length(find(gnd_test == pred_test_label5'))) / length(gnd_test);
    acc = tmp_acc5;
end


