function [nl,nLs,nLs_en,nUlbl,runs] = get_setting(dataName)

switch dataName
    case 'CNAE-9'
        nl = 50;
        nLs = [10];
        nLs_en = [10];
        nUlbl = 750;
        runs = 1:10;
        
    case 'connect-4-10k'
        nl = 500;
        nLs = [5,10,20];
        nLs_en = [10];
        nUlbl = 7500;
        runs = 1:10;
        
    case 'dna_all'
        nl = 159;
        nLs = [5,10,20];
        nLs_en = [10];
        nUlbl = 2400;
        runs = 1:10;
        
    case 'protein.all'
        nl = 1200;
        nLs = [5,10,20];
        nLs_en = [10];
        nUlbl = 18000;
        runs = 1:10;
        
    case 'rcv1_train.multiclass'
        nl = 760;
        nLs = [5,10,20];
        nLs_en = [30,40,50];
        nUlbl = 11000;
        runs = 1:10;
        
    case 'rcv1_all.multiclass'
        nl = 20000;
        nLs = [10];
        nLs_en = [20];
        nUlbl = 400000;
        runs = 1:10;
        
end



