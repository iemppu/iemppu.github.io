% This script runs the expr on "CNAE-9" dataset

dataName = 'CNAE-9';
n_labeled = 50;
n_unlabeled = 750;
runs = 1:10;

do_rossel_par = 1;
do_libsvm_ensemble = 0;
do_liblinear = 1;
do_libsvm = 0;


% ================= baselines =================
if do_liblinear
run_liblinear_v0815(dataName,n_labeled,n_unlabeled,runs,5)
end

if do_libsvm
run_libsvm_v0815(dataName,n_labeled,n_unlabeled,runs,5)
end

if do_libsvm_ensemble
run_libsvm_en_v0815(dataName,n_labeled,n_unlabeled,runs,5)
run_libsvm_en_v0815(dataName,n_labeled,n_unlabeled,runs,10)
run_libsvm_en_v0815(dataName,n_labeled,n_unlabeled,runs,20)
run_libsvm_en_v0815(dataName,n_labeled,n_unlabeled,runs,30)
run_libsvm_en_v0815(dataName,n_labeled,n_unlabeled,runs,40)
run_libsvm_en_v0815(dataName,n_labeled,n_unlabeled,runs,50)
run_libsvm_en_v0815(dataName,n_labeled,n_unlabeled,runs,100)
run_libsvm_en_v0815(dataName,n_labeled,n_unlabeled,runs,200)
end
% ================= baselines =================



if do_rossel_par
run_rossel_par_v0815(dataName,n_labeled,n_unlabeled,runs,5)
run_rossel_par_v0815(dataName,n_labeled,n_unlabeled,runs,10)
run_rossel_par_v0815(dataName,n_labeled,n_unlabeled,runs,20)
run_rossel_par_v0815(dataName,n_labeled,n_unlabeled,runs,30)
run_rossel_par_v0815(dataName,n_labeled,n_unlabeled,runs,40)
run_rossel_par_v0815(dataName,n_labeled,n_unlabeled,runs,50)
end


% ========== OpenMP version is under construction ==========
% if do_rossel_par_omp
% run_rossel_par_omp_v0815(dataName,n_labeled,n_unlabeled,runs,5)
% run_rossel_par_omp_v0815(dataName,n_labeled,n_unlabeled,runs,10)
% run_rossel_par_omp_v0815(dataName,n_labeled,n_unlabeled,runs,20)
% run_rossel_par_omp_v0815(dataName,n_labeled,n_unlabeled,runs,30)
% run_rossel_par_omp_v0815(dataName,n_labeled,n_unlabeled,runs,40)
% run_rossel_par_omp_v0815(dataName,n_labeled,n_unlabeled,runs,50)
% end

