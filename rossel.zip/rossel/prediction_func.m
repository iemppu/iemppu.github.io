function prediction = prediction_func(alpha,y_set,beta,X, X_test)
% prediction function 

ind = find(beta > 1e-2);
prediction = (alpha'.*(beta(ind)'*y_set(ind,:)))*X'*X_test;

end