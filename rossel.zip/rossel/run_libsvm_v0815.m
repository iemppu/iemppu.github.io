% This is the experiment script for ensebmle multiclass/multilabel transduction learning
% hmdb51 contains 3570 training data, 1530 testing data
% NOTE: we use all training data as labeled data, and all testing data as
% the unlabeled data

function run_libsvm_v0815(dataName,nlabel,para_nUnlabel,runs,nK)

% bigDatasets = {'aloi.scale'};

do_liblinear = 0;
do_libsvm = 1;

method = 'libsvm';
% dataName = 'covtype.scale01'; % 580k in total
% dataName = 'aloi100.scale.norm';
% runs = [1];  % # of repeated runs

dataDir = '../datasets/';
splitDir = 'split/';

if ~exist(splitDir,'dir')
    system(sprintf('mkdir %s',splitDir))
end

resampleDir = 'resampleIndex/';
labMatDir = 'labMat/';
alphaDir = 'alpha/';
resultDir = 'result_addAllsel/';
resultDir_bk = resultDir;
resultSumDir = 'result_addAllselF/';
if ~exist(resampleDir,'dir')
    eval(['mkdir ',resampleDir])
end
if ~exist(labMatDir,'dir')
    eval(['mkdir ',labMatDir])
end
if ~exist(alphaDir,'dir')
    eval(['mkdir ',alphaDir])
end
if ~exist(resultDir,'dir')
    eval(['mkdir ',resultDir])
end
if ~exist(resultSumDir,'dir')
    eval(['mkdir ',resultSumDir])
end

% para_num_labeledIndex_perClass = [7];
% para_num_unlabeledIndex = [3213]; % 3570 training data / 1530 testing data

para_s = [3];  % initial liblinear
para_libC = [1];  % initial liblinear
% para_tranC1 = [1e-5,1e-4,1e-3,1e-2,1e-1,1e+0,1e+1,1e+2,1e+3,1e+4,1e+5];
% para_tranC2 = [1e-5,1e-4,1e-3,1e-2,1e-1,1e+0,1e+1,1e+2,1e+3,1e+4,1e+5];
% para_tranC1 = [1e-3,1e-2,1e-1,1e+0,1e+1,1e+2,1e+3];
% para_tranC2 = [1e-3,1e-2,1e-1,1e+0,1e+1,1e+2,1e+3];

switch dataName
    case 'dna_all'
        para_tranC1 = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3];
        para_tranC2 = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3];
    case 'protein.all'
        para_tranC1 = [1e-5,1e-3,1e-1,1e+0,1e+1];
        para_tranC2 = [1e-5,1e-3,1e-1,1e+0,1e+1];
    case 'covtype10000.scale01'
        para_tranC1 = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3,1e+5];
        para_tranC2 = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3,1e+5];
    case 'connect-4-10k'
        para_tranC1 = [1e-5,1e-3,1e-1,1e+0,1e+1];
        para_tranC2 = [1e-5,1e-3,1e-1,1e+0,1e+1];
    case 'rcv1_train.multiclass'
        para_tranC1 = [1e-5,1e-3,1e-1,1e+0,1e+1];
        para_tranC2 = [1e-5,1e-3,1e-1,1e+0,1e+1];
    otherwise
        para_tranC1 = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3,1e+5];
        para_tranC2 = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3,1e+5];
end

nLearner = nK;  % # of learners
% nlabel = [190]; % 38*5
% para_nUnlabel = [2000];
para_nSelectedKernel = nK;
Kernel = 'rbf';
KernelParam = [1];
para_Kernelfun = {'bin'};

para_nLabel = [0.5];  % (the ratio) # of labeled data after bootstrap sampling

cwd = pwd;
% addpath([cwd,'/WellSVM_SSL/WellSVM-liblinear/matlab'])
addpath('/home/yayan/ICCV2015/multiclassTransduction/compMethods/WellSVM_SSL/WellSVM-liblinear/matlab')
addpath('/home/yayan/src/liblinear-1.96/matlab/')
addpath('/home/yayan/src/libsvm/matlab')

%% ------------------- Load data and groundtruth labels -------------------
% NOTE: fea, X (or sth else) should be matrices with row vectors
[fea,gnd] = loadData(dataDir,dataName);

gnd = gnd(:);
if length(unique(gnd)) == 2 && sum(unique(gnd)~=[-1;1]) ~= 0 % for binary classification
    gnd(gnd==2) = -1;
    assert(sum(unique(gnd)~=[-1;1]) == 0,'Bad binary problem!')
end

values = unique(gnd);
K = length(values);
for idx_run=runs
%% generate split index
dataset.splitDir = splitDir;
dataset.dataName = dataName;
dataset.num_labeledIndex_perClass = ceil(nlabel/K);
dataset.num_labeledIndex = dataset.num_labeledIndex_perClass*K;

for idx_nUnlabel=1:length(para_nUnlabel)
    nUnlabel = para_nUnlabel(idx_nUnlabel);
    
dataset.num_unlabeledIndex = nUnlabel;
dataset.num_testIndex = size(gnd,1)-dataset.num_labeledIndex-dataset.num_unlabeledIndex;

[labeledIndex,unlabeledIndex,testIndex,K] = ...
    generate_splitsIndex(gnd,dataset,idx_run);

X_labeled = fea(:,labeledIndex);
X_unlabeled = fea(:,unlabeledIndex);
X_test = fea(:,testIndex);

gnd_labeled = gnd(labeledIndex,:);
gnd_test = gnd(testIndex,:);

n_labeled = size(X_labeled,2);
n_test = size(X_test,2);

%% construct label_multi
label_multi = [gnd_labeled; zeros(size(X_unlabeled,2),1)];
numbers = hist(label_multi(1:n_labeled),0:K);
base = sum(numbers(1+1:K+1)); % do not consider 0 (unlabeled data)
for c = 1:K
    options.lr(c) = numbers(1+c) / base;
end



%% comparisons with baselines

% --------- liblinear for comparison ---------
if do_liblinear
best_acc_liblinear = 0;
bestOutTime_liblinear = 0;
para_lib_s = [1:4];
para_lib_c = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3,1e+5];
for idx_lib_s=1:length(para_lib_s)
    lib_s = para_lib_s(idx_lib_s);
for idx_lib_c=1:length(para_lib_c)
    lib_c = para_lib_c(idx_lib_c);
liboptions = sprintf('-q -s %d -c %f',lib_s,lib_c);
t0_liblinear = clock;
libm = train(gnd_labeled,sparse(X_labeled),liboptions,'col');
t1_liblinear = clock;
outTime_liblinear = etime(t1_liblinear,t0_liblinear);
[lib_pred,lib_acc,lib_dv] = predict(gnd_test,sparse(X_test),libm,'-q','col');
fprintf('liblinear acc = %0.4f | s=%d | c=%f\n',lib_acc(1),lib_s,lib_c)
if best_acc_liblinear < lib_acc(1)
    best_acc_liblinear = lib_acc(1);
    best_para_liblinear = sprintf('s%d_c%0.5f',lib_s,lib_c);
    bestOutTime_liblinear = outTime_liblinear;
end
end % liblinear_c
end % liblinear_s
end

% --------- libsvm for comparison ---------
if do_libsvm
if ~strcmp(dataName,'aloi.scale')
    best_acc_libsvm = 0;
    para_lib_t = [0];
    para_lib_c = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3,1e+5];
    for idx_lib_t=1:length(para_lib_t)
        lib_t = para_lib_t(idx_lib_t);
    for idx_lib_c=1:length(para_lib_c)
        lib_c = para_lib_c(idx_lib_c);
    liboptions = sprintf('-q -t %d -c %f',lib_t,lib_c);
    t0_libsvm = clock;
    libsvmm = svmtrain(gnd_labeled,X_labeled',liboptions);
    t1_libsvm = clock;
    outTime_libsvm = etime(t1_libsvm,t0_libsvm);
    [libsvm_pred,libsvm_acc,libsvm_dv] = svmpredict(gnd_test,X_test',libsvmm,'-q');
    fprintf('libsvm acc = %0.4f | t=%d | c=%f\n',libsvm_acc(1),lib_t,lib_c)
    if best_acc_libsvm < libsvm_acc(1)
        best_acc_libsvm = libsvm_acc(1);
        best_para_libsvm = sprintf('t%0.5f_c%0.5f',lib_t,lib_c);
        bestOutTime_libsvm = outTime_libsvm;
    end
    end % libsvm_c
    end % libsvm_t
end
end


saveFile = sprintf('%s%s_%s_nl%d_nUlbl%d_run%d.mat',...
            resultDir,dataName,method,nlabel,dataset.num_unlabeledIndex,idx_run);

    save(saveFile,'best_acc_libsvm','best_para_libsvm',...
        'bestOutTime_libsvm')


end % nUnlabel

end % runs


% mmap = mean(map(:));
% macc = mean(acc(:));
% % save alpha, sigma and results to file
% saveFile = [resultSumDir,dataName,'_SP',num2str(idx_split),'_nl',num2str(para_nlabel(idx_nlabel)),...
%     '_nLnr',num2str(para_nLearner(idx_nLearner)),'_F',num2str(idx_forTimes),...
%     '_K_',para_Kernel{idx_Kernel},'_KP',num2str(para_KernelParam(idx_KernelParam)),...
%     '_Kf_',para_Kernelfun{idx_Kernelfun},'_nK',num2str(para_nSelectedKernel(idx_nSelectedKernel)),...
%     '_C1',num2str(para_tranC1(idx_tranC1)),'_C2',num2str(para_tranC2(idx_tranC2))];
% save(saveFile,'mmap','macc')



%% **** THE END **** 
