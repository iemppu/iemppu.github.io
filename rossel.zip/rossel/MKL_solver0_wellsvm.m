function [ap,acc,models,MAP] = MKL_solver0_wellsvm(activeSet_C,X,labsize,X_test,gnd_test,options)
% Perform MKL to solve the problem
% activeSet_C:   active set for MKL
% X:             dim*(n_labeled+n_unlabeled), feature matrix of training data
% X_test:        dim*n_test, feature matrix of testing data
%
% map:           mean average precision
% acc:           accuracy
% tmp_alpha:     dual variable alpha
% tmp_sigma:     base kernel coefficient
% tmp_w:         weight

dim = size(X,1);
L = options.nSelectedKernel;
n_test = size(X_test,2);
if size(gnd_test,1)==1 || size(gnd_test,2)==1
    vecFlag = 1;
    K = length(unique((gnd_test)));
    if K==2
        K = 1;
    end
else
    vecFlag = 0;
    K = size(gnd_test,1);
end

w = cell(K,1);
alpha = cell(K,1);
sigma = cell(K,1);
obj = cell(1,1);

t_y = ones(size(X,2),1);

    y_set = activeSet_C{1};
    if isempty(w{1})
        w{1} = zeros(1,dim*size(y_set,1));
        alpha{1} = zeros(1,size(X,2));
        sigma{1} = ones(size(y_set,2),1)/size(y_set,1);
    end

    % Multiple label-kernel learning
    liblinear_options = ['-s 3 -c ' num2str(options.tranC1) ' -B -1'];
    t_w = w{1};
    t_alpha = alpha{1};
    t_sigma = sigma{1};
    
%     for idd=1:length(activeSet_C)
%         activeSet_C{idd} = activeSet_C{idd}';
%     end

    t0 = clock;
    models = cell(length(activeSet_C),1);
    for iii=1:length(activeSet_C)
        models{iii} = well_train(t_y,sparse(X'),liblinear_options,size(activeSet_C{iii},2),activeSet_C{iii},t_sigma,t_w,t_alpha,options.tranC2,labsize);
    end
    t1 = clock;
    outTime_well = etime(t1,t0);
%     fprintf('wellsvm takes %0.4f seconds\n',outTime_well)
    
%     models = Mctran2_par(t_y,sparse(X'),liblinear_options,size(activeSet_C{1},2),activeSet_C,t_sigma,t_w,t_alpha,options.tranC2,labsize);
    
%     models = Mctran4_par_dup(t_y,sparse(X'),liblinear_options,size(activeSet_C{end},2),activeSet_C(end),t_sigma,t_w,t_alpha,options.tranC2,labsize);
    
%     t0 = clock;
%     models = Mctran5_par_ssl(t_y,sparse(X'),liblinear_options,size(activeSet_C{end},2),activeSet_C,t_sigma,t_w,t_alpha,options.tranC2,labsize);
% %     models = Mctran6_omppar_ssl(t_y,sparse(X'),liblinear_options,size(activeSet_C{end},2),activeSet_C,t_sigma,t_w,t_alpha,options.tranC2,labsize);
%     t1 = clock;
%     outTime = etime(t1,t0);
%     fprintf('mctran takes %0.4f seconds\n',outTime)
    
%     % --------------- compare? ---------------
%     for iii=1:length(activeSet_C)
%         fprintf('%d\n',norm(models_well{iii}.w-models{iii}.w));
%         fprintf('%d\n',norm(models_well{iii}.alpha-models{iii}.alpha));
%         fprintf('%d\n',norm(models_well{iii}.sigma-models{iii}.sigma));
%         fprintf('%d\n',norm(models_well{iii}.obj-models{iii}.obj));
% %         fprintf('%d\n',norm(models_well{iii}.Parameters-models{iii}.Parameters));
% %         fprintf('%d\n',norm(models_well{iii}.nr_class-models{iii}.nr_class));
% %         fprintf('%d\n',norm(models_well{iii}.nr_feature-models{iii}.nr_feature));
% %         fprintf('%d\n',norm(models_well{iii}.bias-models{iii}.bias));
% %         fprintf('%d\n',norm(models_well{iii}.Label-models{iii}.Label));
%     
% %         tmp_diff = norm(models_well{iii}.w-models{iii}.w);
% %         assert(tmp_diff<1e-1,'Not identical!')
% %         tmp_diff = norm(models_well{iii}.alpha-models{iii}.alpha);
% %         assert(tmp_diff<1e-1,'Not identical!')
% %         tmp_diff = norm(models_well{iii}.sigma-models{iii}.sigma);
% %         assert(tmp_diff<1e-1,'Not identical!')
% %         tmp_diff = norm(models_well{iii}.obj-models{iii}.obj);
% %         assert(tmp_diff<1e-1,'Not identical!')
% %         tmp_diff = norm(models_well{iii}.Parameters-models{iii}.Parameters);
% %         assert(tmp_diff<1e-1,'Not identical!')
% %         tmp_diff = norm(models_well{iii}.nr_class-models{iii}.nr_class);
% %         assert(tmp_diff<1e-1,'Not identical!')
% %         tmp_diff = norm(models_well{iii}.nr_feature-models{iii}.nr_feature);
% %         assert(tmp_diff<1e-1,'Not identical!')
% %         tmp_diff = norm(models_well{iii}.bias-models{iii}.bias);
% %         assert(tmp_diff<1e-1,'Not identical!')
% %         tmp_diff = norm(models_well{iii}.Label-models{iii}.Label);
% %         assert(tmp_diff<1e-1,'Not identical!')
%     
%     end
%     % --------------- compare? ---------------

%% Predict on entire unlabeled data and compute accuracy
n_addMore = 20;
base_num = 1.1;
pred_filtLab2bk = cell(L,1);
voting_mat1 = zeros(K,n_test);
sum_mat1 = zeros(K,n_test);
voting_mat2 = zeros(K,n_test);
voting_mat2bk = cell(L,1);

for ii = 1:n_addMore
    voting_mat2bk{ii} = zeros(K,(n_test));
end
pred_decVal1 = zeros(K,n_test);
pred_decVal2 = zeros(K,n_test);
%             pred_filtLab1 = zeros(K,n_unlabeled);
pred_filtLab2 = zeros(K,n_test);
%             y = [Y{l},zeros(K,options.nUnlabel)];
for c = 1:K   
%     pred_decVal1(c,:) = prediction_func(tmp_alpha{c},activeSet_C{c}',tmp_sigma{c},X,X_test);
    pred_decVal1(c,:) = prediction_func(models{c}.alpha,activeSet_C{c}',models{c}.sigma,X,X_test);

    [pred_filtLab2(c,:),pred_decVal2(c,:)] = threshold(pred_decVal1(c,:),options.lr(c)); % after "threshold", the labels are +1/-1
    for ii = 1:n_addMore
        try
            [pred_filtLab2bk{ii}(c,:)] = threshold(pred_decVal1(c,:),options.lr(c)*base_num^ii);
        end
    end  
end
sum_mat1 = sum_mat1 + pred_decVal1;
voting_mat1 = voting_mat1 + sign(pred_decVal1);
pred_filtLab2(pred_filtLab2 == -1) = 0;
voting_mat2 = voting_mat2 + pred_filtLab2;

for ii = 1:n_addMore
    try
        pred_filtLab2bk{ii}(pred_filtLab2bk{ii} == -1) = 0;
        voting_mat2bk{ii} = voting_mat2bk{ii} + pred_filtLab2bk{ii};
    end
end

if K>2
if vecFlag
    % ***** Start computing accuracy *****
    % 1. Use original voting (voting_mat1)
    [~,pred_test_label1] = max(voting_mat1,[],1);
    if ~exist('un_acc_vot1','var')
        un_acc_vot1 = [];
    end
    tmp_acc1 = (length(find(gnd_test == pred_test_label1'))) / length(gnd_test);
    un_acc_vot1 = [un_acc_vot1;tmp_acc1];

    % 2. Use balanced labels for VOTING without refining
    for ii = 1:n_addMore
        try
            if sum(sum(voting_mat2)==0) == 0
                break
            end
            zeroIndex = find(sum(voting_mat2)==0);
            voting_mat2(:,zeroIndex) = voting_mat2bk{ii}(:,zeroIndex);
        end
    end
    [~,pred_test_label2] = max(voting_mat2,[],1);
    if ~exist('un_acc_vot2','var')
        un_acc_vot2 = [];
    end
    tmp_acc2 = (length(find(gnd_test == pred_test_label2'))) / length(gnd_test);
    un_acc_vot2 = [un_acc_vot2;tmp_acc2];

    % 3. Use refined labels to vote
    voting_mat3 = zeros(K,length(pred_decVal1(c,:)));
    for c = 1:K
        [voting_mat3(c,:)] = threshold(pred_decVal1(c,:),options.lr(c));
    end
    [~,pred_test_label3] = max(voting_mat3,[],1);
    tmp_acc3 = (length(find(gnd_test == pred_test_label3'))) / length(gnd_test);
    un_acc_vot2 = [un_acc_vot2;tmp_acc3];

    % 4. Use decision value to vote
    sum_pred = zeros(K,length(pred_decVal1(c,:)));
    for c = 1:K
        [sum_pred(c,:)] = threshold(sum_mat1(c,:),options.lr(c));
    end
    [~,pred_test_label4] = max(sum_pred,[],1);
    tmp_acc4 = (length(find(gnd_test == pred_test_label4'))) / length(gnd_test);
    un_acc_vot2 = [un_acc_vot2;tmp_acc4];
    
    
    % 5. Use the original decision values
    [~,pred_test_label5] = max(pred_decVal1,[],1);
    tmp_acc5 = (length(find(gnd_test == pred_test_label5'))) / length(gnd_test);
    un_acc_vot2 = [un_acc_vot2;tmp_acc5];
%     disp(['ACC: ',num2str(max([un_acc_vot1;un_acc_vot2]))])
    
    acc = [un_acc_vot1;un_acc_vot2];
else
    acc = [];
end

else  % if K<=2
    
if vecFlag
    % ***** Start computing accuracy *****
    % 1. Use original voting (voting_mat1)
    pred_test_label1 = voting_mat1;
    if ~exist('un_acc_vot1','var')
        un_acc_vot1 = [];
    end
    tmp_acc1 = (length(find(gnd_test == pred_test_label1'))) / length(gnd_test);
    un_acc_vot1 = [un_acc_vot1;tmp_acc1];

    % 2. Use balanced labels for VOTING without refining
    for ii = 1:n_addMore
        try
            if sum(sum(voting_mat2)==0) == 0
                break
            end
            zeroIndex = find(sum(voting_mat2)==0);
            voting_mat2(:,zeroIndex) = voting_mat2bk{ii}(:,zeroIndex);
        end
    end
    pred_test_label2 = (voting_mat2);
    if ~exist('un_acc_vot2','var')
        un_acc_vot2 = [];
    end
    tmp_acc2 = (length(find(gnd_test == pred_test_label2'))) / length(gnd_test);
    un_acc_vot2 = [un_acc_vot2;tmp_acc2];

    % 3. Use refined labels to vote
    voting_mat3 = zeros(K,length(pred_decVal1(c,:)));
    for c = 1:K
        [voting_mat3(c,:)] = threshold(pred_decVal1(c,:),options.lr(c));
    end
    pred_test_label3 = (voting_mat3);
    tmp_acc3 = (length(find(gnd_test == pred_test_label3'))) / length(gnd_test);
    un_acc_vot2 = [un_acc_vot2;tmp_acc3];

    % 4. Use decision value to vote
    sum_pred = zeros(K,length(pred_decVal1(c,:)));
    for c = 1:K
        [sum_pred(c,:)] = threshold(sum_mat1(c,:),options.lr(c));
    end
    pred_test_label4 = sum_pred;
    tmp_acc4 = (length(find(gnd_test == pred_test_label4'))) / length(gnd_test);
    un_acc_vot2 = [un_acc_vot2;tmp_acc4];
    
    
    % 5. Use the original decision values
    pred_test_label5 = sign(pred_decVal1);
    tmp_acc5 = (length(find(gnd_test == pred_test_label5'))) / length(gnd_test);
    un_acc_vot2 = [un_acc_vot2;tmp_acc5];
%     disp(['ACC: ',num2str(max([un_acc_vot1;un_acc_vot2]))])
    
    acc = [un_acc_vot1;un_acc_vot2];
else
    acc = [];
end
end

% ***** Start computing MAP *****
if vecFlag
    gnd_mat = repmat(gnd_test,1,K)==repmat(1:K,length(gnd_test),1);
else
    gnd_mat = gnd_test';
end

% 1. Use original voting matrix
ap_vot1 = evaluationMAP_yan(gnd_mat,voting_mat1');
MAP.map_vot1 = mean(ap_vot1);

% 2. Use balanced voting matrix
ap_vot2 = evaluationMAP_yan(gnd_mat,pred_decVal2');
MAP.map_vot2 = mean(ap_vot2);

% 3. Use balanced voting generated by original decision values to generate labels
ap_vot3 = evaluationMAP_yan(gnd_mat,pred_decVal1');
MAP.map_vot3 = mean(ap_vot3);

% 4. Use summed decision values from all learners
ap_vot4 = evaluationMAP_yan(gnd_mat,sum_mat1');
MAP.map_vot4 = mean(ap_vot4);

ap = ap_vot4;

