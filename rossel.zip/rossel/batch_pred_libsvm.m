function [part_P] = batch_pred_libsvm(model_cell,X)
% model_cell: L*K cell where each element contains a libsvm model
% X: dim*n where dim is the dimension and n is # of samples

n = size(X,2);
[L,K] = size(model_cell);
part_P = cell(L,1);
for l=1:L
    part_P{l} = zeros(K,n);
    for c=1:K
        [labs,acc,proba] = svmpredict(ones(n,1),sparse(X'),model_cell{l,c},'-b 1');
        if model_cell{l,c}.Label(1) == 1
            part_P{l}(c,:) = proba(:,1)';
        else
            part_P{l}(c,:) = proba(:,2)';
        end
    end
end
