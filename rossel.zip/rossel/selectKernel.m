function [selectedKernelIndex] = selectKernel(otherLabMat,predLab,X_unlabeled,options,label_multi,L)
% Perform labeling kernel selection according to similarity
%
% OtherLabMat:       L*1 cell. Predicted label matrices for L subsets
% predLab:           n_unlabeled*L. Predicted label vectors of L learners
% options:           we will use: Kernel, KernelParam, Kernelfun, and nSelectedKernel
%
% selectedKernelIndex:          ranking index with length L.
L = length(otherLabMat);
if size(label_multi,1)==1 || size(label_multi,2)==1
    % this is for multiclass
    if strcmp(options.Kernelfun,'vec')
        % Compute similarity of labeling and feature
        KK_opts.Kernel = options.Kernel;
        KK_opts.KernelParam = options.KernelParam;
        KK = calckernel(KK_opts,X_unlabeled');
        sim = diag(predLab' * (KK) * predLab);
        [~,selectedKernelIndex] = sort(sim,'descend');
    else
        % Compute similarity of labeling and feature
        KK_opts.Kernel = options.Kernel;
        KK_opts.KernelParam = options.KernelParam;
        KK = calckernel(KK_opts,X_unlabeled');
        sim = zeros(L,1);
        for l = 1:L
            sim(l) = trace(otherLabMat{l} * (KK) * otherLabMat{l}');
        end
        [~,selectedKernelIndex] = sort(sim,'descend');
    end

else
    % Compute similarity of labeling and feature
    KK_opts.Kernel = options.Kernel;
    KK_opts.KernelParam = options.KernelParam;
    KK = calckernel(KK_opts,X_unlabeled');
    sim = zeros(L,1);
    parfor l = 1:L
        sim(l) = trace(otherLabMat{l} * (KK) * otherLabMat{l}');
    end
    [~,selectedKernelIndex] = sort(sim,'descend');
end

if options.nSelectedKernel<length(selectedKernelIndex)
    % selectedKernelIndex = selectedKernelIndex(1:ceil(length(selectedKernelIndex)*options.nSelectedKernel));
    selectedKernelIndex = selectedKernelIndex(1:options.nSelectedKernel);
end