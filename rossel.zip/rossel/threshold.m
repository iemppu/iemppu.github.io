function [y2,y2_decVal] = threshold(y1,lr)
% refine the prediction to satisfy the balance constraint
  
unlab_s = length(y1);
lr = ceil(unlab_s*lr);  
y2 = -ones(length(y1),1);
[val,inx] = sort(y1,'descend');
y2((inx(1:lr))) = 1;

y2_decVal = zeros(length(y1),1);
y2_decVal(inx(1:lr)) = val(1:lr);
    