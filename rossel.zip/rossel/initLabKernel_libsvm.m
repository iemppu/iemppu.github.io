function [initLabMat,otherLabMat,predLab] = initLabKernel_libsvm(X_labeled,label_multi,labeledIndex_l,X_unlabeled,options)
% Train liblinear svms on labeled data, and predict on unlabeled data
% this function uses libsvm to generate labels
%
% X_labeled:                 entire labeled data, dim * n1
% label_multi:               label vector for multiclass; label matrix for multi-label
% labeledIndex_l:            index of labeled data, nLabel * L
% X_unlabeled:               entire unlabeled data, dim * n2
%
% initLabMat:                label matrix by all labeled data
% otherLabMat:               label matrices by L labeled subsets. L*1 cell
% predLab:                   label vector by L labeled subsets. L

n_labeled = size(X_labeled,2);
L = size(labeledIndex_l,2);
n_unlabeled = size(X_unlabeled,2);
if size(label_multi,1)==1 || size(label_multi,2)==1
    % *** this is for multiclass ***
    values = unique(label_multi(label_multi~=0));
    K = length(values);
    % Use all labeled data to train a liblinear (Hard labels)
    model = svmtrain(label_multi(1:n_labeled), sparse(X_labeled'), ['-q -s ',num2str(options.s),' -t ', num2str(options.lib_t)]);
    [initLabVec] = svmpredict(ones(n_unlabeled,1),sparse(X_unlabeled'),model,'-q');
    % Make initial labels a label matrix
    if K>2
        initLabMat = (repmat(initLabVec,1,K) == repmat(1:K,n_unlabeled,1))';
        initLabMat = initLabMat*2-1;
    else
        initLabMat = initLabVec(:)';
    end
    
    otherLabMat = cell(L,1);
    predLab = zeros(n_unlabeled,L);
    for l = 1:L
        t0 = clock;
        model = svmtrain(label_multi(labeledIndex_l(:,l)),sparse(X_labeled(:,labeledIndex_l(:,l))'),['-q -s ',num2str(options.s),' -t ', num2str(options.lib_t)]);
        % predict on entire unlabeled data
        [tmp_predLab] = svmpredict(ones(n_unlabeled,1),sparse(X_unlabeled'),model,'-q');
        predLab(:,l) = tmp_predLab(:);
        if K>2
            otherLabMat{l} = (repmat(tmp_predLab,1,K)==repmat(1:K,n_unlabeled,1))';
            otherLabMat{l} = otherLabMat{l}*2-1;
        else
            otherLabMat{l} = tmp_predLab(:)';
        end
        t1 = clock;
        tt = etime(t1,t0);
        disp(['Learner ',num2str(l),'/',num2str(L),': ',num2str(tt),' seconds'])
    end
else
    % *** this part is for multi-label ***
    K = size(label_multi,1);
    % Use all labeled data to train a liblinear (Hard labels)
    initLabMat = zeros(K,n_unlabeled);
    parfor c = 1:K
        model = svmtrain(label_multi(c,1:n_labeled)', sparse(double(X_labeled)), ['-q -s ',num2str(options.s),' -t ', num2str(options.lib_t)]);
        [initLabVec] = svmpredict(ones(n_unlabeled,1),sparse(double(X_unlabeled')),model);
        % add them into the label matrix
        initLabMat(c,:) = initLabVec';
    end
    % train a liblinear for one learner, and use it to predict entire unlabeled
    otherLabMat = cell(L,1); % first coord is # of data. second coord is # of model
    % predLab = cell(L,1);
    parfor l = 1:L
        t0 = clock;
        for c = 1:K
            model = svmtrain(label_multi(c,labeledIndex_l(:,l))',sparse(X_labeled(:,labeledIndex_l(:,l))'),['-q -s ',num2str(options.s),' -t ', num2str(options.lib_t)]);
            % predict on entire unlabeled data
            [tmp_predLab] = svmpredict(ones(n_unlabeled,1),sparse(X_unlabeled'),model);
            otherLabMat{l}(c,:) = tmp_predLab;
        end
        t1 = clock;
        disp(['Learner ',num2str(l),'/',num2str(L),': ',num2str(etime(t1,t0)),' seconds'])
    end
    predLab = [];
end
