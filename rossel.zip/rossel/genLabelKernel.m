function [activeSet_C] = genLabelKernel(X_labeled, label_multi, bootstrapIndex, X_unlabeled, weak_opt)


[initLabMat,otherLabMat] = initLabKernel(X_labeled,label_multi,bootstrapIndex,X_unlabeled,weak_opt);

% Do not forget to make labels to +1/-1
initLabMat(initLabMat==0) = -1;
for idx_o = 1:length(otherLabMat)
    otherLabMat{idx_o}(otherLabMat{idx_o}==0) = -1;
end


[activeSet_C] = genActive(label_multi(1:size(X_labeled,2)),initLabMat,otherLabMat);