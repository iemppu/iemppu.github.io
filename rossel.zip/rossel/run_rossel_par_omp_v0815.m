function run_rossel_par_omp_v0815(dataName, num_labeled_data, num_unlabeled_data, num_run, num_annotator)
% dataName: e.g. rcv1
% num_labeled_data: number of labeled data
% num_unlabeled_data: number of unlabeled data
% num_run: number of random runs
% num_Kernel: number of label kernels


methodName = 'rossel_omp';
% addpath('/home/yayan/ICCV2015/multiclassTransduction/compMethods/WellSVM_SSL/WellSVM-liblinear/matlab')
addpath('./WellSVM-liblinear/matlab')
addpath('/home/yayan/src/liblinear-1.96/matlab/')
addpath('/home/yayan/src/libsvm/matlab')
dataDir = '../datasets/';

resultDir = 'result_ssl/';
if ~exist(resultDir,'dir')
    eval(['mkdir ',resultDir])
end



para_tranC1 = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3];
para_tranC2 = [1e-5,1e-3,1e-1,1e+0,1e+1,1e+3];

para_weak_ratio = [0.5];  % (the ratio) # of labeled data after bootstrap sampling

weak_annotator_s = 3;  % initial liblinear (weak annotators)
weak_annotator_libC = 1;  % initial liblinear (weak annotators)

%% ------------------- Load data and groundtruth labels -------------------
% NOTE: fea, X (or sth else) should be matrices with row vectors
[fea,gnd] = loadData(dataDir,dataName);

gnd = gnd(:);
values = unique(gnd);
num_class = length(values);
if length(unique(gnd)) == 2 && sum(unique(gnd)~=[-1;1]) ~= 0 % for binary classification
    gnd(gnd==2) = -1;
    assert(sum(unique(gnd)~=[-1;1]) == 0,'Bad binary problem!')
end



for idx_run=num_run
    %% generate split index
    splitDir = 'split/';
    
    if ~exist(splitDir,'dir')
        system(sprintf('mkdir %s',splitDir))
    end
    
    dataset.splitDir = splitDir;
    dataset.dataName = dataName;
    dataset.num_labeledIndex_perClass = ceil(num_labeled_data/num_class);
    dataset.num_labeledIndex = dataset.num_labeledIndex_perClass*num_class;
    dataset.num_unlabeledIndex = num_unlabeled_data;
    dataset.num_testIndex = size(gnd,1)-dataset.num_labeledIndex-dataset.num_unlabeledIndex;
    
    [labeledIndex,unlabeledIndex,testIndex,num_class] = generate_splitsIndex(gnd,dataset,idx_run);
    
    X_labeled = fea(:,labeledIndex);
    X_unlabeled = fea(:,unlabeledIndex);
    X_test = fea(:,testIndex);
    
    gnd_labeled = gnd(labeledIndex,:);
    gnd_test = gnd(testIndex,:);
    
    n_labeled = size(X_labeled,2);
    n_test = size(X_test,2);
    
    %% construct label_multi
    label_multi = [gnd_labeled; zeros(size(X_unlabeled,2),1)];
    numbers = hist(label_multi(1:n_labeled),0:num_class);
    base = sum(numbers(1+1:num_class+1)); % do not consider 0 (unlabeled data)
    for c = 1:num_class
        options.lr(c) = numbers(1+c) / base;
    end
    
    bestAcc_enmctran = 0;
    bestOutTime = 0;
    for idx_weak_ratio=1:length(para_weak_ratio)
        weak_ratio = para_weak_ratio(idx_weak_ratio);
        options.nLabel = dataset.num_labeledIndex * weak_ratio;
        
        options.nLearner = num_annotator;
        
        [bootstrapIndex] = bootstrapResample(options.nLearner,options.nLabel,label_multi);
        
        weak_opt.s = weak_annotator_s;
        weak_opt.libC = weak_annotator_libC;
        
        t0_pre = clock;
        
        % Generate label kernels
        [activeSet_C] = genLabelKernel(X_labeled, label_multi, bootstrapIndex, X_unlabeled, weak_opt);
        
        t1_pre = clock;
        outTime_preprocess = etime(t1_pre,t0_pre);
        
        %% Iteration on tranC1 and tranC2
        for idx_tranC1 = 1:length(para_tranC1)
            for idx_tranC2 = 1:length(para_tranC2)
                options.tranC1 = para_tranC1(idx_tranC1);
                options.tranC2 = para_tranC2(idx_tranC2);
                
                t0 = clock;
                % Solve MKL
                %         [map,acc,alpha,sigma,w] = MKL_solver(activeSet_C,[X_labeled,X_unlabeled],size(X_labeled,2),X_test,gnd_test,options);
                [acc,models] = MKL_solver_par_omp(activeSet_C,[X_labeled,X_unlabeled],size(X_labeled,2),X_test,gnd_test,options);
                % save alpha, sigma and results to file
                t1 = clock;
                outTime = etime(t1,t0);
                
                para_string = sprintf('nl%d_nUnlbl%d_nL%d_nLabBoot%f_run%d_C1%0.4f_C2%0.4f',...
                    num_labeled_data,dataset.num_unlabeledIndex,options.nLearner,weak_ratio,idx_run,...
                    options.tranC1,options.tranC2);
                
                saveFile = sprintf('%s%s_%s_nl%d_nUnlbl%d_nL%d_nLabBoot%f_run%d_C1%0.4f_C2%0.4f.mat',...
                    resultDir,dataName,methodName,num_labeled_data,dataset.num_unlabeledIndex,options.nLearner,weak_ratio,idx_run,...
                    options.tranC1,options.tranC2);
                %         save(saveFile,'map','acc','ap','para_string')
                
                fprintf('%s acc = %0.4f | %0.4f s | %s\n', methodName, acc(end), outTime, para_string)
                
                if bestAcc_enmctran<acc(end)
                    bestAcc_enmctran = acc(end);
                    bestParam = para_string;
                    bestOutTime = outTime;
                end
                % save to sumary results
            end % for of tranC2
        end
        
    end
    
    saveFile = sprintf('%s%s_%s_nl%d_nUlbl%d_nL%d_run%d.mat',...
        resultDir,dataName,methodName,num_labeled_data,dataset.num_unlabeledIndex,options.nLearner,idx_run);
    save(saveFile,'bestAcc_enmctran','bestParam',...
        'bestOutTime',...
        'outTime_preprocess')
    
end % num_run

%% **** THE END ****
