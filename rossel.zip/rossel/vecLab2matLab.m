function [T] = vecLab2matLab(Y)
% This function transforms label vector to label matrix

if size(Y,1)>size(Y,2)
    Y = Y';
end

labels=unique(Y);
[~,indexes]=ismember(Y,labels);
rows = 1:length(Y); %// row indx
T = zeros(length(Y),length(unique(indexes))); %// A matrix full of zeros
T(sub2ind(size(T),rows ,indexes)) = 1; %// Ones at the desired row/column combinations

