function [initLabMat,otherLabMat,predLab] = initLabKernel(X_labeled,label_multi,labeledIndex_l,X_unlabeled,options)
% Train liblinear svms on labeled data, and predict on unlabeled data
%
% X_labeled:                 entire labeled data, dim * n1
% label_multi:               label vector for multiclass; label matrix for multi-label
% labeledIndex_l:            index of labeled data, nLabel * L
% X_unlabeled:               entire unlabeled data, dim * n2
%
% initLabMat:                label matrix by all labeled data
% otherLabMat:               label matrices by L labeled subsets. L*1 cell
% predLab:                   label vector by L labeled subsets. L

n_labeled = size(X_labeled,2);
L = size(labeledIndex_l,2);
n_unlabeled = size(X_unlabeled,2);

values = unique(label_multi(label_multi~=0));
K = length(values);
% Use all labeled data to train a liblinear
model = train(label_multi(1:n_labeled), sparse(X_labeled), ['-q -s ',num2str(options.s),' -c ', num2str(options.libC)],'col');
[initLabVec] = predict(ones(n_unlabeled,1),sparse(X_unlabeled),model,'-q','col');
% Make initial labels a label matrix
if K>2
    initLabMat = (repmat(initLabVec,1,K) == repmat(1:K,n_unlabeled,1))';
    initLabMat = initLabMat*2-1;
else
    initLabMat = initLabVec(:)';
end

otherLabMat = cell(L,1);
predLab = zeros(n_unlabeled,L);
for l = 1:L
    t0 = clock;
    model = train(label_multi(labeledIndex_l(:,l)),sparse(X_labeled(:,labeledIndex_l(:,l))),['-q -s ',num2str(options.s),' -c ', num2str(options.libC)],'col');
    % predict on entire unlabeled data
    [tmp_predLab] = predict(ones(n_unlabeled,1),sparse(X_unlabeled),model,'-q','col');
    predLab(:,l) = tmp_predLab(:);
    if K>2
        otherLabMat{l} = (repmat(tmp_predLab,1,K)==repmat(1:K,n_unlabeled,1))';
        otherLabMat{l} = otherLabMat{l}*2-1;
    else
        otherLabMat{l} = tmp_predLab(:)';
    end
    t1 = clock;
    tt = etime(t1,t0);
    disp(['Learner ',num2str(l),'/',num2str(L),': ',num2str(tt),' seconds'])
end